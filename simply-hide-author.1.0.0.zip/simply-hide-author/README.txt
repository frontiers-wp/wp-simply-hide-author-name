=== Simply Hide Author ===
Contributors: Frontiers
Donate link: https://paypal.me/EBekedam
Tags: author, spam, hide
Requires at least: 5.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Just Hides the author name from your WordPress blog.

== Description ==

Do you want to hide and disable the comment author link in WordPress and hide the real user author name from the blog post? 
This is a plugin that is minimalist with not much code; only PHP script and little CSS will be inlined to ensure that the author 
is no longer visible to the online public.


Competibliabty for hiding author:  Slim SEO, Yoast WP SEO, Rank Math.




== Installation ==

1. Upload 'simply-hide-author.zip' to the '/wp-content/plugins/' directory
2. Extract the Plugin to a `nodoss` Folder
3. Activate the plugin through the 'Plugins' menu in WordPress
4. no settings need - just Activate and enjoy.

== OR ==

1. Go to 'Plugins' in the Admin menu
2. Click on the button 'Add new' 
3. Search for 'simply-hide-author' and click 'Install Now' or click on the `upload` link to upload `nodoss.zip`
4. Click on 'Activate plugin' 


== Frequently Asked Questions ==

= A question that someone might have =

An answer to that question.

== Screenshots ==

1. This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif). Note that the screenshot is taken from
the /assets directory or the directory that contains the stable readme.txt (tags or trunk). Screenshots in the /assets
directory take precedence. For example, `/assets/screenshot-1.png` would win over `/tags/4.3/screenshot-1.png`
(or jpg, jpeg, gif).
2. This is the second screen shot

== Changelog ==

= 1.0.0: November 01, 2025 =
* Birthday of Simply Hide Author

Ordered list:

1. Some feature
1. Another feature
1. Something else about the plugin