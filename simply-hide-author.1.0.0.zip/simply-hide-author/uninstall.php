<?php
/**
 * Fired when the plugin is uninstalled.
 * For more information, see the following discussion:
 * https://github.com/tommcfarlin/WordPress-Plugin-Boilerplate/pull/123#issuecomment-28541913
 *
 * @link       https://https://wordpress.org/plugins/simplyhideauthor
 * @since      1.0.0
 *
 * @package    Simply_Hide_Author
 */

// If uninstall not called from WordPress, then exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/**
 * Remove Option on uninstalling/deleting the Plugin.
 */
function simply_hide_author_plugin_version_uninstall() {
	delete_option( 'simply_hide_author_plugin_version' );
}

/**
 * Remove Fields on uninstalling/deleting the Plugin.
 */
delete_option('simply_hide_author_plugin_fields');