<?php
/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Simply_Hide_Author
 * @subpackage Simply_Hide_Author/includes
 * @author     Frontiers <wordpress@bekamhealing.com>
 */
class Simply_Hide_Author_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}
    
	/**
	 * Specify all codes required for plugin uninstall here.
	 *
	 */
	public function uninstall() {
        // delete plugin options
        delete_option('simply_hide_author_options');
        // delete plugin transient
        delete_transient('simply_hide_author_transient');
    }

}