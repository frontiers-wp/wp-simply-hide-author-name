<?php
/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    Simply_Hide_Author
 * @subpackage Simply_Hide_Author/includes
 * @author     Frontiers <wordpress@bekamhealing.com>
 */ 
class Simply_Hide_Author {

    /**
     * The loader that's responsible for maintaining and registering all hooks that power
     * the plugin.
     *
     * @since    1.0.0
     * @access   protected
     * @var      Simply_Hide_Author_Loader    $loader    Maintains and registers all hooks for the plugin.
     */
    protected $loader;

    /**
     * The unique identifier of this plugin.
     *
     * @since    1.0.0
     * @access   protected
     * @var      string    $plugin_name    The string used to uniquely identify this plugin.
     */
    protected $plugin_name;

    /**
     * The current version of the plugin.
     *
     * @since    1.0.0
     * @access   protected
     * @var      string    $version    The current version of the plugin.
     */
    protected $version;

    /**
     * Define the core functionality of the plugin.
     *
     * Set the plugin name and the plugin version that can be used throughout the plugin.
     * Load the dependencies, define the locale, and set the hooks for the admin area and
     * the public-facing side of the site.
     *
     * @since    1.0.0
     */
    public function __construct() {
        if ( defined( 'SIMPLY_HIDE_AUTHOR_VERSION' ) ) {
            $this->version = SIMPLY_HIDE_AUTHOR_VERSION;
        } else {
            $this->version = '1.0.0';
        }
        $this->plugin_name = 'simply-hide-author';

        $this->load_dependencies();
    }

    /**
     * Load the required dependencies for this plugin.
     *
     * Include the following files that make up the plugin:
     *
     * - Simply_Hide_Author_Loader. Orchestrates the hooks of the plugin.
     * - Simply_Hide_Author_i18n. Defines internationalization functionality.
     * - Simply_Hide_Author_Admin. Defines all hooks for the admin area.
     * - Simply_Hide_Author_Public. Defines all hooks for the public side of the site.
     *
     * Create an instance of the loader which will be used to register the hooks
     * with WordPress.
     *
     * @since    1.0.0
     * @access   private
     */
    private function load_dependencies() {

        /**
         * The class responsible for orchestrating the actions and filters of the
         * core plugin.
         */
        require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-simply-hide-author-loader.php';

        // $this->loader = new Simply_Hide_Author_Loader();
    }
    
    	/**
	 * Run the loader to execute all of the hooks with WordPress.
	 *
	 * @since    1.0.0
	 */
	public function run() {
		$this->loader->run();
	}

	/**
	 * The name of the plugin used to uniquely identify it within the context of
	 * WordPress and to define internationalization functionality.
	 *
	 * @since     1.0.0
	 * @return    string    Simply_Hide_Author
	 */
	public function get_plugin_name() {
		return $this->plugin_name;
	}

	/**
	 * The reference to the class that orchestrates the hooks with the plugin.
	 *
	 * @since     1.0.0
	 * @return    Simply_Hide_Author_Loader    Orchestrates the hooks of the plugin.
	 */
	public function get_loader() {
		return $this->loader;
	}

	/**
	 * Retrieve the version number of the plugin.
	 *
	 * @since     1.0.0
	 * @return    string    The version number of the plugin.
	 */
	public function get_version() {
		return $this->version;
	}
    
    /**
     * CSS rules for hiding author elements
     *
     * @var array
     */
    private const CSS_RULES = [
        '.entry-meta ul li:before'   => 'display: none !important',
        '.entry-meta .byline:after'  => 'display: none !important',
        'li.meta-author'             => 'display: none !important',
        '.entry-meta .byline'        => 'display: none !important',
        '.entry-meta .cat-links'     => 'display: none !important',
        '.author-name'               => 'display: none !important',
        '.post-author'               => 'display: none !important',
        '.entry-author'              => 'display: none !important',
        '.posted-on'                 => 'display: none !important',
        '.post .author-name'         => 'display: none !important',
        '.entry-meta .author.vcard'  => 'display: none !important',
    ];

    /**
     * Inject CSS to hide author elements
     */
    public function inject_hide_author_css() {
        $style = '<style>';
        foreach (self::CSS_RULES as $selector => $rule) {
            $style .= sprintf(
                '%s {%s} ',
                esc_html($selector),
                esc_html($rule)
            );
        }
        $style .= '</style>';

        echo wp_kses($style, ['style' => []]);
    }

    /**
     * Remove author links from the content
     *
     * @since    1.0.0
     * @param    string    $content    The post content
     * @return   string    The modified content
     */
    public function remove_author_links( $content ) {
        $pattern = '/<a[^>]+class="url fn n"[^>]*>(.*?)<\/a>/i';
        $replacement = '$1';
        return preg_replace( $pattern, $replacement, $content );
    }

    /**
     * Register all of the hooks related to the public-facing functionality
     * of the plugin.
     *
     * @since    1.0.0
     */
    private function define_public_hooks() {
        add_filter( 'the_content', array( $this, 'remove_author_links' ) );
    }

    /**
     * Register all hooks
     */
    private function init_hooks() {
        // SEO robots filter
        add_filter('slim_seo_robots_index', [$this, 'disable_author_archive_indexing'], 10, 2);

        // CSS injection
        add_action('wp_head', [$this, 'inject_hide_author_css'], 20);

        // Data removal
        add_action('init', [$this, 'remove_author_data']);
        add_action('init', [$this, 'remove_seo_author_data']);
    }

    /**
     * Disable indexing for author archive pages
     *
     * @param mixed $value
     * @param int $object_id
     * @return mixed
     */
    public function disable_author_archive_indexing($value, $object_id) {
        if (is_author()) {
            return false;
        }
        return $value;
    }

    /**
     * Remove author-related data from templates
     */
    public function remove_author_data() {
        // Generic callback to return empty string
        $return_empty = function() {
            return '';
        };

        // Remove author display
        add_filter('the_author', $return_empty);
        add_filter('get_the_author_display_name', $return_empty);

        // Remove date/time information
        add_filter('the_date', $return_empty);
        add_filter('the_time', $return_empty);
        add_filter('the_modified_date', $return_empty);
        add_filter('get_the_date', $return_empty);
        add_filter('get_the_time', $return_empty);
        add_filter('get_the_modified_date', $return_empty);

        // Remove author links
        add_filter('author_link', $return_empty);
        add_filter('get_the_author', $return_empty);

        // Slim SEO LinkedIn Tags
        add_filter('slim_seo_linkedin_author', $return_empty);
    }

    /**
     * Remove author data from SEO plugins
     */
    public function remove_seo_author_data() {
        // Disable Yoast SEO author schema
        add_filter('wpseo_schema_person', '__return_false');
        add_filter('wpseo_schema_needs_author', '__return_false');
        add_filter('wpseo_meta_author', '__return_false');

        // Disable Slim SEO author schema
        add_filter('slim_seo_schema_author_enable', '__return_false');

        // Disable Rank Math author entity
        add_filter('rank_math/snippet/rich_snippet_article_entity', '__return_false');
    }
}
