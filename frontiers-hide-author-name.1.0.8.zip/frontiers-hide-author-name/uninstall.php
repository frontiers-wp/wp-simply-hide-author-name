<?php
/**
 * Fired when the plugin is uninstalled.
 * Optimized for maximum database cleanup execution speeds in PHP 8.5+.
 *
 * @link       https://https://wordpress.org/plugins/frontiers-hide-author-name
 * @since      1.0.7
 * @package    Frontiers_Hide_Author_Name
 */

// If uninstall not called from WordPress, then exit immediately.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/**
 * Self-invoking structural routine to cleanly wipe option keys.
 */
(static function(): void {
	// 1. Delete main plugin configuration data options
	delete_option( 'frontiers_hide_author_name_plugin_fields' );

	// 2. Delete plugin tracker version records
	delete_option( 'frontiers_hide_author_name_plugin_version' );
	
	// 3. Delete general options if present (synchronized with the deactivator class)
	delete_option( 'frontiers_hide_author_name_options' );

	// 4. Clean up lingering transients to free up database table space
	delete_transient( 'frontiers_hide_author_name_transient' );
})();
