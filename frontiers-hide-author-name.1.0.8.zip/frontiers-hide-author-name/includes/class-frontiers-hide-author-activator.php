<?php 
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Fired during plugin activation.
 *
 * @since      1.0.6
 * @package    Frontiers_hide_author_name
 * @subpackage Frontiers_Hide_Author_name/includes
 * @author     Frontiers <wordpress@bekamhealing.com>
 */

if (!class_exists('frontiers_hide_author_name_Activator')) {

    class frontiers_hide_author_name_Activator {

        /**
         * Main activation handler.
         * Initializes plugin options.
         *
         * @since    1.0.0
         */
        public static function activate() {
            $activator = new self();
            $activator->install();
        }

        /**
         * Initializes plugin options during activation.
         *
         * @since    1.0.0
         */
        protected function install() {
            $this->init_options();
        }

        /**
         * Sets up default plugin options.
         *
         * @since    1.0.0
         */
        private function init_options() {
            // Setup default options if they don't exist yet
            if (false === get_option('frontiers_hide_author_name_options')) {
                update_option('frontiers_hide_author_name_options', []);
            }
        }
    }
}
