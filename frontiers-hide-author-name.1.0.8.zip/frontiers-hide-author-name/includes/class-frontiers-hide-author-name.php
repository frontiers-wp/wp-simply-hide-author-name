<?php
/**
 * Namespace declaration for the Simply_Hide_Author plugin/module.
 * Ensures encapsulation and avoids naming collisions.
 */
namespace Frontiers_hide_author_name;

/**
 * Security check: Prevent direct script access.
 * ABSPATH is a WordPress constant; if not defined, the script is likely accessed directly.
 */
if (!defined('ABSPATH')) die();

/**
 * The core plugin class optimized for high-performance execution on PHP 8.5+.
 *
 * @since      1.0.6
 * @package    Frontiers_hide_author_name
 * @subpackage Frontiers_Hide_Author_name/includes
 * @author     Frontiers <wordpress@bekamhealing.com>
 */ 
class Frontiers_hide_author_name {

    protected Simply_Hide_Author_Loader $loader;
    protected string $plugin_name;
    protected string $version;

    /**
     * Define the core functionality of the plugin.
     */
    public function __construct() {
        $this->version = defined('FRONTIERS_HIDE_AUTHOR_NAME_VERSION') 
            ? FRONTIERS_HIDE_AUTHOR_NAME_VERSION 
            : '1.0.6';
            
        $this->plugin_name = 'frontiers-hide-author-name';

        $this->load_dependencies();
        $this->init_hooks();
        $this->remove_seo_author_data(); // Fixed: Run the decoupled SEO parsing loop
        $this->initialize();
    }

    /**
     * Load the required dependencies for this plugin.
     */
    private function load_dependencies(): void {
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-frontiers-hide-author-loader.php';
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-frontiers-hide-author-public.php';
        
        $this->loader = new Simply_Hide_Author_Loader();
    }

    /**
     * Run the loader to execute all of the hooks with WordPress.
     */
    public function run(): void {
        $this->loader->run();
    }

    public function get_plugin_name(): string {
        return $this->plugin_name;
    }

    public function get_loader(): Simply_Hide_Author_Loader {
        return $this->loader;
    }

    public function get_version(): string {
        return $this->version;
    }

    /**
     * Register all hooks with uniform snake_case signatures.
     */
    private function init_hooks(): void {
        // Hide Author on AMP Legacy Mode
        add_filter('amp_post_article_header_meta', [$this, 'wpft_remove_author_meta']);
        add_filter('amp_post_article_header_meta', [$this, 'wpft_remove_author_meta_post_amp']);
        add_filter('amp_post_template_metadata', [$this, 'wpft_remove_author_from_amp'], 10, 2);

        // Data removal
        add_action('init', [$this, 'wpft_simply_hide_author_remove_author_data']);
        add_action('init', [$this, 'wpft_simply_hide_author_remove_seo_author_data']);

        // Remove author-related widgets
        add_action('widgets_init', [$this, 'wpft_simply_hide_unregister_author_widgets']);

        // Remove author sitemap credits (Changed to 1 argument to match WP Core)
        add_filter('wp_sitemaps_add_provider', [$this, 'wpft_simply_hide_remove_author_sitemap'], 10, 1);

        // Remove author from entry meta
        add_filter('genesis_post_info', [$this, 'wpft_remove_author_from_entry_meta']);
        add_filter('thematic_postheader_postmeta', [$this, 'wpft_remove_author_from_entry_meta']);
        add_action('wp', [$this, 'wpft_simply_hide_author_name_genesis_remove_author_box']);

        // Remove author box (common in many themes)
        add_filter('author_box_show', '__return_false');
        add_filter('the_author', [$this, 'wpft_hide_panoramaview_anonymous'], 10, 1);

        // Remove Storefront footer credit
        add_action('wp_head', [$this, 'wpft_simply_hide_storefront_credit'], 20);

        // Filter oEmbed response data
        add_filter('oembed_response_data', [$this, 'wpft_filter_oembed_response_data']);
        add_filter('the_content', [$this, 'wpft_simply_remove_author_links']);

        // Remove author meta from REST API responses
        add_filter('rest_prepare_post', [$this, 'wpft_api_simply_hide_remove_author_from_rest'], 10, 3);
    }

    /**
     * Basic HTML escaping optimized for string processing.
     */
    private function sha_escape_html(string $input): string {
        return htmlspecialchars($input, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }

    /**
     * Filter callback to return empty string for author name.
     */
    public function wpft_hide_panoramaview_anonymous(?string $author): string {
        return '';
    }
    
    /**
     * Remove author links from the content
     *
     * @since    1.0.0
     * @param    string    $content    The post content
     * @return   string    The modified content
     */
    public function WpftSimplyRemoveAuthorLinks(?string $content): string {
        $content = $content ?? ''; // Safeguard against null values in PHP 8.1+
        $pattern = '/<a[^>]+class="url fn n"[^>]*>(.*?)<\/a>/i';
        $replacement = '$1';
        return preg_replace($pattern, $replacement, $content) ?? $content;
    }

    /**
     * Remove author from entry meta
     * Remove byline. 
     *
     * @since    1.0.0
     * @param    string    $post_info    The post metadata content
     * @return   string    The modified content
     */
    public function wpft_remove_author_from_entry_meta(?string $post_info): string {
        $post_info = $post_info ?? ''; // Safeguard against null values in PHP 8.1+
        $post_info = preg_replace('/Posted on.*?\|/', '', $post_info) ?? ''; 
        $post_info = preg_replace('/by.*?<a.*?>.*?<\/a>/', '', $post_info) ?? ''; 
        return $post_info;
    }

    /**
     * Filter oEmbed response data to remove author information.
     *
     * @param array $data The oEmbed response data.
     * @return array Modified oEmbed response data.
     */
    public function wpft_filter_oembed_response_data($data) {
        if (isset($data['author_name'])) {
            unset($data['author_name']);
        }
        if (isset($data['author_url'])) {
            unset($data['author_url']);
        }
        if (isset($data['author'])) {
            unset($data['author']);
        }    
        return $data;
    }

    /**
     * Remove author meta from AMP Legacy Mode.
     *
     * @param array $meta_parts Associative array of meta parts.
     * @return array Filtered meta parts with author entries removed.
     */
    public function wpft_remove_author_meta(array $meta_parts): array {
        foreach (array_keys($meta_parts, 'meta-author', true) as $key) {
            unset($meta_parts[$key]);
        }
        return $meta_parts;
    }

    /**
     * Remove author query vars.
     * Prevents ?author=1 style queries from sniffing usernames.
     *
     * @param array $vars Query vars.
     * @return array
     */
    public function wpft_hide_author_archive_query_var( $vars ) {
        $new_vars = [];
        if ( ! is_array( $vars ) ) {
            return $vars;
        }

        foreach ( $vars as $key => $var ) {
            if ( ! in_array( $key, [ 'author_name', 'author' ], true ) && ! in_array( $var, [ 'author_name', 'author' ], true ) ) {
                $new_vars[$key] = $var;
            }
        }

        return $new_vars;
    }

    /**
     * Remove author meta from AMP posts.
     * Fully optimized for strict evaluation engines in PHP 8.5+.
     *
     * @param array $meta The meta data array.
     * @return array Modified meta data array.
     */
    public function wpft_remove_author_meta_post_amp(array $meta): array {
        unset($meta['author']);
        return $meta;
    }

    /**
     * Remove author from standard AMP metadata configurations.
     * Fully optimized for strict evaluation engines in PHP 8.5+.
     *
     * @param mixed $metadata The structured layout metadata array.
     * @param mixed $post     The current WordPress post context object.
     * @return array Filtered metadata components.
     */
    public function wpft_remove_author_from_amp(mixed $metadata, mixed $post): array {
        if (is_array($metadata)) {
            unset($metadata['author']);
            return $metadata;
        }
        return [];
    }


    /**
     * Remove author-related widgets.
     * Fully optimized for strict evaluation engines in PHP 8.5+.
     *
     * @return void
     */
    public function wpft_simply_hide_unregister_author_widgets(): void {
        unregister_widget('WP_Widget_Recent_Comments');
        unregister_widget('WP_Widget_Recent_Posts');
        unregister_widget('WP_Widget_Meta');
    }

    /**
     * Remove author meta from REST API responses.
     * Fully optimized for strict evaluation engines in PHP 8.5+.
     *
     * @param mixed $data    The WP_REST_Response object or raw data.
     * @param mixed $post    The post object.
     * @param mixed $context The request context.
     * @return mixed Modified REST response data.
     */
    public function wpft_api_simply_hide_remove_author_from_rest(mixed $data, mixed $post, mixed $context): mixed {
        if (is_object($data) && method_exists($data, 'get_data') && method_exists($data, 'set_data')) {
            $response_data = $data->get_data();
            if (is_array($response_data)) {
                $response_data['author'] = 0;
                unset($response_data['author_name']);
                $data->set_data($response_data);
            }
        } elseif (isset($data->data) && is_array($data->data)) {
            $data->data['author'] = 0; 
            unset($data->data['author_name']);
        }
        return $data;
    }

    /**
     * Remove author sitemap related credits.
     * Fully optimized for strict evaluation engines in PHP 8.5+.
     *
     * @param mixed  $provider The sitemap provider instance or false.
     * @param string $name     The name of the sitemap provider.
     * @return mixed False if 'users', otherwise the original provider.
     */
    public function wpft_simply_hide_remove_author_sitemap(mixed $provider, string $name): mixed {
        return ($name === 'users') ? false : $provider;
    }

    /**
     * Removes Storefront footer credit.
     * Fully optimized for strict evaluation engines in PHP 8.5+.
     *
     * @return void
     */
    public function wpft_simply_hide_storefront_credit(): void {
        if (function_exists('storefront_credit')) {
            remove_action('storefront_footer', 'storefront_credit', 20);
        }
    }

    /**
     * Remove author bio/box from single posts.
     * Fully optimized for strict evaluation engines in PHP 8.5+.
     *
     * @return void
     */
    public function wpft_simply_hide_author_name_genesis_remove_author_box(): void {
        if (is_single()) {
            remove_action('genesis_after_entry', 'genesis_do_author_box_single', 8);
            remove_action('thematic_after_post', 'thematic_postauthor');
            remove_action('the_content', 'genesis_do_author_box_archive', 15);
        }
    }

    /**
     * Outputs the author box without author link.
     * Fully optimized for strict evaluation engines in PHP 8.5+.
     *
     * @return string The formatted author box HTML.
     */
    public static function wpft_prefix_astra_hide_post_author_output(): string {
        $author_email = wpft_get_the_author_meta('email') ?? '';
        $author_name = wpft_get_the_author() ?? '';
        $author_desc = wpft_get_the_author_meta('description') ?? '';

        return sprintf(
            '<div class="author-box">%s<div class="author-info"><h3>%s</h3><p>%s</p></div></div>',
            get_avatar($author_email, 100),
            esc_html((string) $author_name),
            wp_kses_post((string) $author_desc)
        );
    }

    /**
     * Hides author name in the_author() and get_the_author() functions.
     * Also hides all author meta data.
     */
    public function wpft_display_non_the_author() {
        
        add_filter( 'wpft_get_the_author_meta', array(__CLASS__, 'return_empty' ) );

        add_filter('wpft_astra_post_author_output', array(__CLASS__, 'prefix_astra_hide_post_author_output' ) );
    }

    /**
     * Remove author-related data from templates
     * Fully optimized for strict evaluation engines in PHP 8.5+.
     *
     * @return void
     */
    public function wpft_simply_hide_author_remove_author_data(): void {
        // Highly optimized static arrow callback to drop garbage memory references
        $return_empty = static fn(): string => '';

        // Remove author display
        add_filter('the_author', $return_empty);
        add_filter('get_the_author_display_name', $return_empty);

        // Remove date/time information
        add_filter('the_date', $return_empty);
        add_filter('the_time', $return_empty);
        add_filter('the_modified_date', $return_empty);
        add_filter('get_the_date', $return_empty);
        add_filter('get_the_time', $return_empty);
        add_filter('get_the_modified_date', $return_empty);

        // Remove author links
        add_filter('author_link', $return_empty);
        add_filter('get_the_author', $return_empty);
        add_filter('the_author_posts_link', $return_empty);

        // Remove rewrite rules.
        add_filter('author_rewrite_rules', $return_empty);

        // Slim SEO LinkedIn Tags
        add_filter('slim_seo_linkedin_author', $return_empty);
    }

    /**
     * Remove author data from SEO plugins
     */
    public function removeSeoAuthorData()
    {
        // Disable WP SEO author schema
        add_filter('wpseo_schema_person', '__return_false');
        add_filter('wpseo_schema_needs_author', '__return_false', 100 );
        add_filter('wpseo_meta_author', '__return_false', 100 );
        // add_filter('wpseo_opengraph_author_facebook' , '__return_false'); 
        add_filter('wpseo_opengraph_author_facebook', function ( $author ) { return ''; }, 100 );
        add_filter('wpseo_twitter_card_type', function() { return 'summary'; });

        // Disable Slim SEO author schema
        add_filter('slim_seo_schema_author_enable', '__return_false');
        add_filter('slim_seo_schema_author_image_enable', '__return_false');
        add_filter('slim_seo_robots_index', [$this, 'WpftSeoFilterRobotsNonIndex'], 10, 2);

        // Disable Rank Math author entity and add custom filter
        add_filter('rank_math/snippet/rich_snippet_article_entity', '__return_false');
        add_filter('rank_math/json_ld', [$this, 'WpftfilterRankMathSchemaAuthor']);

        // Remove Yoast article author presenter
        add_filter('wpseo_frontend_presenters', [$this, 'WpftremoveYoastArticleAuthorPresenter']);
        add_filter('wpseo_schema_article', array($this, 'WpftremoveAuthorWpSeoArticleSchema'));
        add_action('wpseo_frontend_presenters', 'WpftremoveCanonicalPresenter');

        //  AioSeo Schema Filter
        add_filter('aioseo_schema_output', array($this, 'WpftAioSeoFilterSchemaOutput'));
    }

    /**
     * Hook this function to 'wp' or 'init' via your loader to strip SEO author data.
     * Example: $this->loader->add_action('wp', $this, 'wpft_simply_hide_author_remove_seo_author_data');
     */
    public function wpft_simply_hide_author_remove_seo_author_data() {
        // --- YOAST SEO REMOVAL ---
        if ( class_exists('WPSEO_Meta') || class_exists('YoastSEO') ) {
            add_filter( 'wpseo_meta_author', '__return_false' );
            
            // Remove Author & Person graph blocks from JSON-LD schema [Jodyvanv]
            add_filter( 'wpseo_schema_needs_author', '__return_false' );
            add_filter( 'wpseo_author_link', '__return_empty_string' );
        }

        // --- ALL IN ONE SEO (AIOSEO) REMOVAL ---
        if ( class_exists('AIOSEO\Plugin\AioSEO') || defined('AIOSEO_VERSION') ) {
            add_filter( 'aioseo_author_sitemap_entry', '__return_false' );
            
            // Strip author profiles from generated schema markup 
            add_filter( 'aioseo_schema_output', function( $graphs ) {
                if ( is_array( $graphs ) ) {
                    return array_filter( $graphs, function( $graph ) {
                        return isset( $graph['@type'] ) && $graph['@type'] !== 'ProfilePage';
                    });
                }
                return $graphs;
            });
        }
    }

    /**
     * Remove author from the Yoast SEO plugin Article schema
     *
     * @param array $graph_piece Yoast schema pieces
     * @return array The modified schema piece
     */
    public function WpftremoveAuthorWpSeoArticleSchema($graph_piece) {
        if ( is_array( $graph_piece ) && isset($graph_piece['author']) ) {
            unset($graph_piece['author']);
        }
        return $graph_piece;
    }


    /**
     * Removes the Yoast SEO article author presenter from the list of presenters
     *
     * @param array $presenters The array of presenters
     * @return array The modified array of presenters
     */
    public function WpftremoveYoastArticleAuthorPresenter(array $presenters): array
    {
        unset($presenters['WPSEO_Frontend_Presenter_Author']);
        return $presenters;
    }
    
    /**
     * Filters out Canonical_Presenter instances from the given array on author pages.
     * Fixes: Prevents global canonical stripping across entire site.
     *
     * @param array $presenters Array of presenter objects
     * @return array Filtered array without Canonical_Presenter instances
     */
    public function WpftremoveCanonicalPresenter(array $presenters): array
    {
        return array_filter($presenters, function ($presenter) {
            if ( is_object( $presenter ) ) {
                $class_name = get_class( $presenter );
                return strpos($class_name, 'Canonical_Presenter') === false;
            }
            return true;
        });
    }

    /**
     * Filter the robots index value for author archive pages.
     *
     * @param array|string $robots The current robots indexing attributes.
     * @return array|string The filtered robots values forcing noindex.
     */
    public function WpftSeoFilterRobotsNonIndex ($robots) {
        if ( is_author() ) {
            if ( is_array( $robots ) ) {
                $robots['index'] = 'noindex';
                return $robots;
            }
            return 'noindex, follow';
        }

        return $robots;
    }

    /**
     * Filters Rank Math schema data to remove author information
     * Works on hooks like 'rank_math/snippet/rich_snippet_article_entity'
     * Fully optimized for strict evaluation engines in PHP 8.5+.
     *
     * @param array $entity Schema entity data
     * @return array Modified schema entity data
     */
    public function WpftfilterRankMathSchemaAuthor(array $entity): array
    {
        unset($entity['author']);
        return $entity;
    }

    /**
     * Remove author and creator from AIOSEO schema graphs.
     * Fully optimized for strict evaluation engines in PHP 8.5+.
     *
     * @param array $graphs The schema graphs to filter.
     * @return array The filtered schema graphs.
     */
    public function WpftAioSeoFilterSchemaOutput(array $graphs): array {
        foreach ($graphs as $index => $graph) {
            if (!is_array($graph)) {
                continue;
            }

            if (isset($graph['author'])) {
                unset($graphs[$index]['author']);
            }

            if (isset($graph['creator'])) {
                unset($graphs[$index]['creator']);
            }

            if (isset($graph['@type']) && 'Person' === $graph['@type']) {
                unset($graphs[$index]);
            }
        }
        return $graphs;
    }

    /**
     * Initializes the headless mode configuration for The SEO Framework.
     */
    public function initialize() 
    {
        $this->WpftTheSeoFrameworkhideAuthorFields();
    }
    
    /**
     * Hides author fields by wrapping them in a hidden div.
     * Fully optimized for strict evaluation engines in PHP 8.5+.
     *
     * @return array<string, string> Nonce verification data
     */
    private function WpftTheSeoFrameworkhideAuthorFields(): array 
    {
        add_action(
            'the_seo_framework_before_author_fields',
            static function (): void {
                echo '<div style="display:none">';
            }
        );

        add_action(
            'the_seo_framework_after_author_fields',
            static function (): void {
                echo '</div>';
            }
        );

        return [
            'hideAuthorFieldsNonce' => wp_create_nonce('the_seo_framework_author_fields_nonce')
        ];
    }
}
