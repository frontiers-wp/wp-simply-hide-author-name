<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
/**
 * This class defines all code necessary to run during the plugin's deactivation.
 * Fully optimized for strict evaluation engines in PHP 8.5+.
 *
 * @since      1.0.6
 * @package    Frontiers_hide_author_name
 * @subpackage Frontiers_Hide_Author_name/includes
 * @author     Frontiers <wordpress@bekamhealing.com>
 */
class frontiers_hide_author_name_Deactivator {

	/**
	 * Fire operational hooks during deactivation.
	 * Utilizing static invocation structures to maintain a zero-byte memory footprint.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate(): void {
		// Clean up rewrite rules if any custom permalinks were flushed
        if (function_exists('flush_rewrite_rules')) {
            flush_rewrite_rules(false);
        }
	}
}
