<?php
/**
 * Namespace declaration for the Simply_Hide_Author plugin/module.
 * Ensures encapsulation and avoids naming collisions.
 */
namespace FrontiersAuthorVisibilityProElementsCSS;

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Author ghost visibility pro Elements - PHP Implementation
 */
if (!defined('ABSPATH') && php_sapi_name() !== 'cli') {
    if (!headers_sent()) {
        header('HTTP/1.0 403 Forbidden');
    }
    exit;
}

/**
 * Function to safely output CSS styles for hiding elements
 *
 * @param array $css_selectors Associative array of CSS selectors and their styles
 */
function frontiers_hide_author_elements_bycss(array $css_selectors) {
    if (empty($css_selectors) || !is_array($css_selectors)) {
        return;
    }

    // Allowed CSS properties and values
    $allowed_properties = [
        'display' => ['none', 'block', 'inline', 'inline-block', 'flex', 'grid'],
        'visibility' => ['hidden', 'visible'],
    ];

    foreach ($css_selectors as $selector => $style) {
        // Sanitize the CSS selector
        $sanitized_selector = preg_replace('/[^a-zA-Z0-9#.:,[\]>\s\-_()=!]/', '', $selector);

        // Sanitize the CSS style
        $sanitized_style = wp_kses($style, [
            'display' => $allowed_properties['display'],
            'visibility' => $allowed_properties['visibility'],
            '!' => true, // For !important
        ]);

        if ($sanitized_selector && $sanitized_style) {
            // Output the sanitized CSS
            echo sprintf(
                '<style>%s {%s}</style>',
                esc_html($sanitized_selector),
                esc_html($sanitized_style)
            );
        }
    }
}

// Define CSS selectors and their corresponding styles to hide author information
$frontiers_hide_author_name_css_selectors = [
    '.entry-meta ul li:before' => 'display: none !important',
    '.entry-meta .byline:after' => 'display: none !important',
    '.entry-meta .byline, .author-info' => 'display: none',
    'ul li.meta-author' => 'display: none !important',
    '.entry-meta .byline' => 'display: none !important',
    '.entry-meta .cat-links' => 'display: none !important',
    '.post .author-name' => 'display: none !important',
    '.author-name' => 'display: none !important',
    '.post-author' => 'display: none !important; visibility: hidden',
    '.author-name-class' => 'display: none !important',
    '.authorbox' => 'display: none !important',
    '.entry-author' => 'display: none !important',
    '.entry-meta .posted-on' => 'display: none !important',
    '.entry-meta .author.vcard' => 'display: none !important',
    '.post-author.meta-wrapper' => 'display: none !important',
    '.mkdf-post-info-author' => 'display: none !important',
    '.amp-wp-meta' => 'display: none !important'
];

// Hook the function to wp_head to output CSS in the head section
add_action('wp_head', function() use ($frontiers_hide_author_name_css_selectors) {
    frontiers_hide_author_elements_bycss($frontiers_hide_author_name_css_selectors);
});
?>