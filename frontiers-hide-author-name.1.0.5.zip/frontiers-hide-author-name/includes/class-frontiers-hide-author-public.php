<?php if (!defined('ABSPATH')) die();

use Frontiers\frontiers_hide_author_name\Plugin;

function frontiers_hide_author_name_nonce_field(){
	Plugin::instance()->nonceField();
}