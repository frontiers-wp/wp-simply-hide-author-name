<?php
/**
 * Fired when the plugin is uninstalled.
 *
 * @link       https://https://wordpress.org/plugins/frontiers-hide-author-name
 * @since      1.0.5
 *
 * @package    Frontiers_Hide_Author_Name
 */

// If uninstall not called from WordPress, then exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/**
 * Remove Option on uninstalling/deleting the Plugin.
 */
function frontiers_hide_author_plugin_version_uninstall() {
	delete_option( 'frontiers_hide_author_name_plugin_version' );
}

/**
 * Remove Fields on uninstalling/deleting the Plugin.
 */
delete_option('frontiers_hide_author_name_plugin_fields');