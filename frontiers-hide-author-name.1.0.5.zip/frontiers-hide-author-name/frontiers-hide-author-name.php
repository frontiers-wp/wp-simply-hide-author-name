<?php
/**
 * @wordpress-plugin
 * Plugin Name:       Frontiers Hide Author Name
 * Plugin URI:        https://wordpress.org/plugins/frontiers-hide-author-name
 * Description:       Hide author name from your WordPress blog
 * Version:           1.0.5
 * Requires at least: 5.0
 * Requires PHP:      7.4
 * Author:            Edwin Bekedam
 * Author URI:        https://github.com/frontiers-wp/wp-simply-hide-author-name
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       frontiers-hide-author-name
 * Domain Path:       /languages
 * License:           GPLv2
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 *
 * You should have received a copy of the GNU General Public License
 * along with Simply Hide Author. If not, see <https://www.gnu.org/licenses/gpl-2.0.html/>.
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'FRONTIERS_HIDE_AUTHOR_NAME_VERSION', '1.0.5' );

/**
 * Base URL of plugin
 */
if ( ! defined( 'FRONTIERS_HIDE_AUTHOR_NAME_BASEURL' ) ) {
	define( 'FRONTIERS_HIDE_AUTHOR_NAME_BASEURL', plugin_dir_url( __FILE__ ) );
}

/**
 * Base Name of plugin
 */
if ( ! defined( 'FRONTIERS_HIDE_AUTHOR_NAME_BASENAME' ) ) {
	define( 'FRONTIERS_HIDE_AUTHOR_NAME_BASENAME', plugin_basename( __FILE__ ) );
}

/**
 * Base PATH of plugin
 */
if ( ! defined( 'FRONTIERS_HIDE_AUTHOR_NAME_BASEPATH' ) ) {
	define( 'FRONTIERS_HIDE_AUTHOR_NAME_BASEPATH', plugin_dir_path( __FILE__ ) );
}

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-frontiers-hide-author-activator.php
 */
function frontiers_hide_author_name_activate() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-frontiers-hide-author-activator.php';
	frontiers_hide_author_name_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-frontiers-hide-author-deactivator.php
 */
function frontiers_hide_author_name_deactivate() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-frontiers-hide-author-deactivator.php';
	frontiers_hide_author_name_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'frontiers_hide_author_name_activate' );
register_deactivation_hook( __FILE__, 'frontiers_hide_author_name_deactivate' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-frontiers-hide-author-name.php';
require plugin_dir_path( __FILE__ ) . 'includes/class-frontiers-hide-author-elements.php';