<?php
/**
 * Namespace declaration for the Simply_Hide_Author plugin/module.
 * Ensures encapsulation and avoids naming collisions.
 */
namespace Simply_Hide_Author;

/**
 * Security check: Prevent direct script access.
 * ABSPATH is a WordPress constant; if not defined, the script is likely accessed directly.
 */
if (!defined('ABSPATH')) die();

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    Simply_Hide_Author
 * @subpackage Simply_Hide_Author/includes
 * @author     Frontiers <wordpress@bekamhealing.com>
 */ 
class Simply_Hide_Author {

    /**
     * The loader that's responsible for maintaining and registering all hooks that power
     * the plugin.
     *
     * @since    1.0.0
     * @access   protected
     * @var      Simply_Hide_Author_Loader    $loader    Maintains and registers all hooks for the plugin.
     */
    protected $loader;

    /**
     * The unique identifier of this plugin.
     *
     * @since    1.0.0
     * @access   protected
     * @var      string    $plugin_name    The string used to uniquely identify this plugin.
     */
    protected $plugin_name;

    /**
     * The current version of the plugin.
     *
     * @since    1.0.0
     * @access   protected
     * @var      string    $version    The current version of the plugin.
     */
    protected $version;

    /**
     * Define the core functionality of the plugin.
     *
     * Set the plugin name and the plugin version that can be used throughout the plugin.
     * Load the dependencies, define the locale, and set the hooks for the admin area and
     * the public-facing side of the site.
     *
     * @since    1.0.0
     */
    public function __construct() {
        if (defined('SIMPLY_HIDE_AUTHOR_VERSION')) {
            $this->version = SIMPLY_HIDE_AUTHOR_VERSION;
        } else {
            $this->version = '1.0.0';
        }
        $this->plugin_name = 'simply-hide-author';

        $this->load_dependencies();
        $this->init_hooks();
    }

    /**
     * Load the required dependencies for this plugin.
     *
     * Include the following files that make up the plugin:
     *
     * - Simply_Hide_Author_Loader. Orchestrates the hooks of the plugin.
     * - Simply_Hide_Author_Admin. Defines all hooks for the admin area.
     * - Simply_Hide_Author_Public. Defines all hooks for the public side of the site.
     *
     * Create an instance of the loader which will be used to register the hooks
     * with WordPress.
     *
     * @since    1.0.0
     * @access   private
     */
    private function load_dependencies() {
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-simply-hide-author-loader.php';
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-simply-hide-author-public.php';
        $this->loader = new Simply_Hide_Author_Loader();
    }

    /**
     * Run the loader to execute all of the hooks with WordPress.
     *
     * @since    1.0.0
     */
    public function run() {
        $this->loader->run();
    }

    /**
     * The name of the plugin used to uniquely identify it within the context of
     * WordPress and to define internationalization functionality.
     *
     * @since     1.0.0
     * @return    string    Simply_Hide_Author
     */
    public function get_plugin_name() {
        return $this->plugin_name;
    }

    /**
     * The reference to the class that orchestrates the hooks with the plugin.
     *
     * @since     1.0.0
     * @return    Simply_Hide_Author_Loader    Orchestrates the hooks of the plugin.
     */
    public function get_loader() {
        return $this->loader;
    }

    /**
     * Retrieve the version number of the plugin.
     *
     * @since     1.0.0
     * @return    string    The version number of the plugin.
     */
    public function get_version() {
        return $this->version;
    }

    /**
     * Register all hooks.
     */
    private function init_hooks() {
        // Hide Author on AMP Legacy Mode
        add_filter('amp_post_article_header_meta', [$this, 'wpft_remove_author_meta']);
        add_filter('amp_post_article_header_meta', [$this, 'wpft_remove_author_meta_post_amp']);

        // CSS injection
        add_action('wp_head', [$this, 'wpft_inject_hide_author_css'], 20);
    
        // Data removal
        add_action('init', [$this, 'wpft_simply_hide_author_remove_author_data']);
        add_action('init', [$this, 'wpft_simply_hide_author_remove_seo_author_data']);

        // Remove Storefront footer credit
        add_action('wp_head', [$this, 'wpft_simply_hide_storefront_credit'], 20);

        // Filter oEmbed response data
        add_filter('oembed_response_data', [$this, 'wpft_filter_oembed_response_data']);

        add_filter('the_content', array($this, 'WpftSimplyRemoveAuthorLinks'));
        add_filter('get_the_author_description', [$authorHider, 'WpftSimplyHideAuthorMeta']);
    }

    /**
     * CSS rules for hiding author elements
     *
     * @var array
     */
    private const WPFT_CSS_RULES = [
        '.entry-meta ul li:before'   => 'display: none !important',
        '.entry-meta .byline:after'  => 'display: none !important',
        '.entry-author .byline'      => 'display: none !important',
        'ul li.meta-author'          => 'display: none !important',
        '.entry-meta .byline'        => 'display: none !important',
        '.entry-meta .cat-links'     => 'display: none !important',
        '.post .author-name'         => 'display: none !important',
        '.author-name'               => 'display: none !important',
        '.post-author'               => 'display: none !important',
        '.entry-author'              => 'display: none !important',
        '.entry-meta .posted-on'     => 'display: none !important',
        '.post .author-name'         => 'display: none !important',
        '.entry-meta .author.vcard'  => 'display: none !important',
        '.post-author.meta-wrapper'  => 'display: none !important',
        '.amp-wp-meta'               => 'display: none !important',
    ];

    /**
     * Inject CSS to hide author elements
     */
    public function wpft_inject_hide_author_css() {
        $style = '<style>';
        foreach (self::WPFT_CSS_RULES as $selector => $rule) {
            $style .= sprintf(
                '%s {%s} ',
                $this->ShaescapeHtml($selector),
                $this->ShaescapeHtml($rule)
            );
        }
        $style .= '</style>';

        echo wp_kses($style, ['style' => []]);
   
        return array('simply_hide_author_nonce_field' => wp_create_nonce('simply-hide-author-css'));
    }

    /**
     * Basic HTML escaping
     * @param string $input
     * @return string
     */
    private function ShaescapeHtml(string $input): string {
        return htmlspecialchars($input, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
    
    /**
     * Remove author links from the content
     *
     * @since    1.0.0
     * @param    string    $content    The post content
     * @return   string    The modified content
     */
    public function WpftSimplyRemoveAuthorLinks(string $content): string {
        $pattern = '/<a[^>]+class="url fn n"[^>]*>(.*?)<\/a>/i';
        $replacement = '$1';
        return preg_replace($pattern, $replacement, $content);
    }

    /**
     * Replaces the default author meta output with a custom message
     *
     * @hook filter get_the_author_description
     * @param string $description The original author description
     * @return string Always returns the "no bio" message
     */
    public function WpftSimplyHideAuthorMeta(string $description = ''): string
    {
        // Always return the no bio message regardless of input
        return 'No bio available for this author.';
    }

    /**
     * Filter oEmbed response data to remove author information.
     *
     * @param array $data The oEmbed response data.
     * @return array Modified oEmbed response data.
     */
    public function wpft_filter_oembed_response_data($data) {
        if (isset($data['author_name'])) {
            unset($data['author_name']);
        }
        if (isset($data['author_url'])) {
            unset($data['author_url']);
        }
        return $data;
    }
    
    /**
     * Remove author meta from AMP Legacy Mode.
     *
     * @param array $meta_parts Associative array of meta parts.
     * @return array Filtered meta parts with author entries removed.
     */
    public function wpft_remove_author_meta(array $meta_parts): array {
        foreach (array_keys($meta_parts, 'meta-author', true) as $key) {
            unset($meta_parts[$key]);
        }
        return $meta_parts;
    }

    /**
     * Remove author meta from AMP posts.
     *
     * @param array $meta The meta data array.
     * @return array Modified meta data array.
     */
    public function wpft_remove_author_meta_post_amp($meta) {
        unset($meta['author']);
        return $meta;
    }

    /**
     * Removes Storefront footer credit.
     */
    public function wpft_simply_hide_storefront_credit() {
        if (function_exists('storefront_credit')) {
            remove_action('storefront_footer', 'storefront_credit', 20);
        }
    }


    /**
     * Outputs the author box without author link.
     *
     * @return string The formatted author box HTML.
     */
    public static function wpft_prefix_astra_hide_post_author_output() {
        return sprintf(
            '<div class="author-box">%s<div class="author-info"><h3>%s</h3><p>%s</p></div></div>',
            get_avatar(wpft_get_the_author_meta('email'), 100),
            esc_html(wpft_get_the_author()),
            wp_kses_post(wpft_get_the_author_meta('description'))
        );
    }

    /**
     * Hides author name in the_author() and get_the_author() functions.
     * Also hides all author meta data.
     */
    public function wpft_display_non_the_author() {
        
        add_filter( 'wpft_get_the_author_meta', array(__CLASS__, 'return_empty' ) );

        add_filter('wpft_astra_post_author_output', array(__CLASS__, 'prefix_astra_hide_post_author_output' ) );
    }

    /**
     * Remove author-related data from templates
     */
    public function wpft_simply_hide_author_remove_author_data() {
        // Generic callback to return empty string
        $return_empty = function() {
            return '';
        };

        // Remove author display
        add_filter('the_author', $return_empty);
        add_filter('get_the_author_display_name', $return_empty);

        // Remove date/time information
        add_filter('the_date', $return_empty);
        add_filter('the_time', $return_empty);
        add_filter('the_modified_date', $return_empty);
        add_filter('get_the_date', $return_empty);
        add_filter('get_the_time', $return_empty);
        add_filter('get_the_modified_date', $return_empty);

        // Remove author links
        add_filter('author_link', $return_empty);
        add_filter('get_the_author', $return_empty);

        // Slim SEO LinkedIn Tags
        add_filter('slim_seo_linkedin_author', $return_empty);
    }

    /**
     * Remove author data from SEO plugins
     */
    public function removeSeoAuthorData()
    {
        // Disable WP SEO author schema
        add_filter('wpseo_schema_person', '__return_false');
        add_filter('wpseo_schema_needs_author', '__return_false');
        add_filter('wpseo_meta_author', '__return_false');
        add_filter('wpseo_opengraph_author_facebook' , '__return_false' ); 

        // Disable Slim SEO author schema
        add_filter('slim_seo_schema_author_enable', '__return_false');
        add_filter('slim_seo_schema_author_image_enable', '__return_false');
        add_filter('slim_seo_robots_index', [$this, 'WpftSeoFilterRobotsNonIndex'], 10, 2);

        // Disable Rank Math author entity and add custom filter
        add_filter('rank_math/snippet/rich_snippet_article_entity', '__return_false');
        add_filter('rank_math/json_ld', [$this, 'WpftfilterRankMathSchemaAuthor']);

        // Remove Yoast article author presenter
        add_filter('wpseo_frontend_presenters', [$this, 'WpftremoveYoastArticleAuthorPresenter']);
        add_filter('wpseo_schema_article', array($this, 'WpftremoveAuthorWpSeoArticleSchema'));
        add_action('wpseo_frontend_presenters', 'WpftremoveCanonicalPresenter'); 

        //  AioSeo Schema Filter
        add_filter('aioseo_schema_output', array($this, 'WpftAioSeoFilterSchemaOutput'));
    }

    /**
     * Removes WP SEO Yoast author data 
     */
    public function wpft_simply_hide_author_remove_seo_author_data() {
        if (class_exists('WPSEO_Meta')) {
            remove_action('wpseo_head', ['WPSEO_Meta', 'author']);
        }
    }

    /**
     * Remove author from the Yoast SEO plugin Article schema
     *
     * @param array $graph_piece Yoast schema pieces
     * @return array The modified schema piece
     */
    public function WpftremoveAuthorWpSeoArticleSchema($graph_piece) {
        unset($graph_piece['author']);
        return $graph_piece;
    }

    /**
     * Removes the Yoast SEO article author presenter from the list of presenters
     *
     * @param array $presenters The array of presenters
     * @return array The modified array of presenters
     */
    public function WpftremoveYoastArticleAuthorPresenter(array $presenters): array
    {
        unset($presenters['WPSEO_Frontend_Presenter_Author']);
        return $presenters;
    }
    
    /**
     * Filters out Canonical_Presenter instances from the given array.
     *
     * @param array $presenters Array of presenter objects
     * @return array Filtered array without Canonical_Presenter instances
     */
    public function WpftremoveCanonicalPresenter(array $presenters): array
    {
        return array_filter($presenters, function ($presenter) {
            return !($presenter instanceof Canonical_Presenter);
        });
    }

    /**
     * Filter the robots index value for author archive pages.
     *
     * @param bool $value     The current robots index value.
     * @param int  $object_id The object ID.
     * @return bool           The filtered robots index value.
     */
    public function WpftSeoFilterRobotsNonIndex ($value, $object_id) {
        if (is_author()) {
            return false;
        }

        return $value;
    }

   /**
    * Filters Rank Math schema data to remove author information
    *
    * @param array $entity Schema entity data
    * @return array Modified schema entity data
    */
    public function WpftfilterRankMathSchemaAuthor(array $entity): array
    {
        if (isset($entity['author'])) {
        unset($entity['author']);
    }
    return $entity;
    }

    /**
     * Remove author and creator from AIOSEO schema graphs
     *
     * @param array $graphs The schema graphs to filter
     * @return array The filtered schema graphs
     */
    public function WpftAioSeoFilterSchemaOutput($graphs) {
        foreach ($graphs as $index => $graph) {
            if (isset($graph['author'])) {
                unset($graphs[$index]['author']);
            }

            if (isset($graph['creator'])) {
                unset($graphs[$index]['creator']);
            }

            if ('Person' === $graph['@type']) {
                unset($graphs[$index]);
            }
        }
        return $graphs;
    }

    /**
     * Initializes the headless mode configuration for The SEO Framework.
     */
    public function initialize() 
    {
        $this->WpftTheSeoFrameworkhideAuthorFields();
    }

    /**
     * Hides author fields by wrapping them in a hidden div.
     *
     * @return array<string, string> Nonce verification data
     */
    private function WpftTheSeoFrameworkhideAuthorFields() 
    {
        add_action(
            'the_seo_framework_before_author_fields',
            function () {
                echo '<div style="display:none">';
            }
        );

        add_action(
            'the_seo_framework_after_author_fields',
            function () {
                echo '</div>';
            }
        );

        return [
            'hideAuthorFieldsNonce' => wp_create_nonce('the_seo_framework_author_fields_nonce')
        ];
    }
}