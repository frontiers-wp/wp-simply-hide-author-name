<?php if (!defined('ABSPATH')) die();

use Frontiers\Simply_Hide_Author\Plugin;

function Simply_Hide_Author_nonce_field(){
	Plugin::instance()->nonceField();
}