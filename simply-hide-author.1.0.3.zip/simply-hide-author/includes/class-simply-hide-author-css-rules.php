<?php
// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Function to safely output CSS styles for hiding elements
 *
 * @param array $css_selectors Associative array of CSS selectors and their styles
 */
function simply_hide_author_elements_by_css( array $css_selectors ): void {
    // Validate and sanitize each CSS selector and style
    foreach ( $css_selectors as $selector => $style ) {
        // Sanitize the CSS selector (basic validation)
        $sanitized_selector = preg_replace( '/[^a-zA-Z0-9#.:,[\]>\s\-_()=!]/', '', $selector );

        // Sanitize the CSS style (basic validation)
        $sanitized_style = wp_kses( $style, [
            'display'     => [ 'none', 'block', 'inline', 'inline-block', 'flex', 'grid' ],
            'visibility'  => [ 'hidden', 'visible' ],
            'important'   => true,
            '!'           => true, // For !important
        ] );

        if ( $sanitized_selector && $sanitized_style ) {
            // Escape output for safe HTML rendering
            echo sprintf(
                '<style>%s {%s}</style>',
                esc_html( $sanitized_selector ),
                esc_html( $sanitized_style )
            );
        }
    }
}

// Define the CSS selectors and their corresponding styles
$simply_hide_author_css_selectors = [
    // Hide the bullet points before list items in the entry-meta
    '.entry-meta ul li:before' => 'display: none !important',

    // Hide the content after the byline in the entry-meta
    '.entry-meta .byline:after' => 'display: none !important',

    // Hide the byline and author info elements
    '.entry-meta .byline, .author-info' => 'display: none',

    // Hide the meta-author list items
    'ul li.meta-author' => 'display: none !important',

    // Hide the byline in the entry-meta
    '.entry-meta .byline' => 'display: none !important',

    // Hide the category links in the entry-meta
    '.entry-meta .cat-links' => 'display: none !important',

    // Hide the author name in the post
    '.post .author-name' => 'display: none !important',

    // Hide the author name
    '.author-name' => 'display: none !important',

    // Hide the post author
    '.post-author' => 'display: none !important; visibility: hidden',

    // Hide the entry author
    '.entry-author' => 'display: none !important',

    // Hide the posted-on in the entry-meta
    '.entry-meta .posted-on' => 'display: none !important',

    // Hide the author vcard in the entry-meta
    '.entry-meta .author.vcard' => 'display: none !important',

    // Hide the post-author meta-wrapper
    '.post-author.meta-wrapper' => 'display: none !important',

    // Hide the amp-wp-meta
    '.amp-wp-meta' => 'display: none !important'
];

// Call the function to hide the elements
simply_hide_author_elements_by_css( $simply_hide_author_css_selectors );
?>