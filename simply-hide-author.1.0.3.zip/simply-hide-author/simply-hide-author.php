<?php
/**
 * @wordpress-plugin
 * Plugin Name:       Simply Hide Author
 * Plugin URI:        https://wordpress.org/plugins/simplyhideauthor
 * Description:       Hide author name from your WordPress blog
 * Version:           1.0.3
 * Requires at least: 5.0
 * Requires PHP:      7.4
 * Author:            Edwin Bekedam
 * Author URI:        https://github.com/frontiers-wp/wp-simply-hide-author-name
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       simply-hide-author
 * Domain Path:       /languages
 * License:           GPLv2
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 *
 * You should have received a copy of the GNU General Public License
 * along with Simply Hide Author. If not, see <https://www.gnu.org/licenses/gpl-2.0.html/>.
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'SIMPLY_HIDE_AUTHOR_VERSION', '1.0.3' );

/**
 * Base URL of plugin
 */
if ( ! defined( 'SIMPLY_HIDE_AUTHOR_BASEURL' ) ) {
	define( 'SIMPLY_HIDE_AUTHOR_BASEURL', plugin_dir_url( __FILE__ ) );
}

/**
 * Base Name of plugin
 */
if ( ! defined( 'SIMPLY_HIDE_AUTHOR_BASENAME' ) ) {
	define( 'SIMPLY_HIDE_AUTHOR_BASENAME', plugin_basename( __FILE__ ) );
}

/**
 * Base PATH of plugin
 */
if ( ! defined( 'SIMPLY_HIDE_AUTHOR_BASEPATH' ) ) {
	define( 'SIMPLY_HIDE_AUTHOR_BASEPATH', plugin_dir_path( __FILE__ ) );
}

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-simply-hide-author-activator.php
 */
function simply_hide_author_activate() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-simply-hide-author-activator.php';
	Simply_Hide_Author_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-simply-hide-author-deactivator.php
 */
function simply_hide_author_deactivate() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-simply-hide-author-deactivator.php';
	Simply_Hide_Author_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'simply_hide_author_activate' );
register_deactivation_hook( __FILE__, 'simply_hide_author_deactivate' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-simply-hide-author.php';

