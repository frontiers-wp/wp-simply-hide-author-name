<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.7
 * @package    Frontiers_hide_author_name
 * @subpackage Frontiers_Hide_Author_name/includes
 * @author     Frontiers <wordpress@bekamhealing.com>
 */
class frontiers_hide_author_name_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}
    
	/**
	 * Specify all codes required for plugin uninstall here.
	 *
	 */
	public function uninstall() {
        // delete plugin options
        delete_option('frontiers_hide_author_name_options');
        // delete plugin transient
        delete_transient('frontiers_hide_author_name_transient');
    }

}