=== Simply hide author name ===
Contributors: Frontiers
Donate link: https://paypal.me/EBekedam
Tags: hide author, spam, bots
Requires at least: 5.0
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.0.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Just Hides the author name from your WordPress blog.

== Description ==

Do you want to hide and disable the comment author link in WordPress and hide the real user author name from the blog post? 
This is a plugin that is minimalist with not much code; only PHP script and little CSS will be inlined to ensure that the author 
is no longer visible to the online public.

This plugin works intergrated.

Yoast SEO,WP Seo, The SEO Framework, AIOSEO, Rank Math, Astra Themes,  

Remove author from general WordPress and author meta from AMP, and removed Storefront author credit.


== Installation ==

1. Upload 'simply-hide-author.zip' to the '/wp-content/plugins/' directory
2. Extract the Plugin to 'simply-hide-author-name' Folder
3. Activate the plugin through the 'Plugins' menu in WordPress
4. no settings need – just Activate and enjoy.

1. Go to 'Plugins' in the Admin menu
2. Click on the button 'Add new' 
3. Search for 'simply-hide-author' and click 'Install Now' or click on the `upload` link to upload 'simply-hide-author-name.zip'
4. Click on 'Activate plugin' 


== Frequently Asked Questions ==

=Witch SEO plugins work togetter witch simply hide author?=

Yoast SEO,WP Seo, The SEO Framework, AIOSEO, Rank Math, Slim SEO

=Does simply hide author has any intergrations with other Themes?=

Yes, o.a. with Astra Themes , Genesis Themes, Twenty Twelve


== Screenshots ==

1. banner-772-250-simply-hide-author.png
2. wp-simply-hide-author-icon.png
3. wp-simply-hide-author.svg

== Changelog ==

= 1.0.0: November 01, 2025 =
* Birthday of Simply Hide Author
= 1.0.1: November 02, 2025 =
* function name update
= 1.0.2: November 20, 2025 =
* Update performance.

== Upgrade Notice ==
Just Hides the author name from your WordPress blog.