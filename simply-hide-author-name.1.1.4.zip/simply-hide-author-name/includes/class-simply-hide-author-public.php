<?php if (!defined('ABSPATH')) die();

use Frontiers\Simply_hide_author_name\Plugin;

function Simply_hide_author_name_nonce_field(){
	Plugin::instance()->nonceField();
}