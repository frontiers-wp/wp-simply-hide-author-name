<?php
/**
 * @wordpress-plugin
 * Plugin Name:       Simply Hide Author
 * Plugin URI:        https://github.com/frontiers-wp/simplyhideauthor
 * Description:       Hide author name from your WordPress blog
 * Version:           1.0.1
 * Requires at least: 5.0
 * Requires PHP:      7.4
 * Author:            Frontiers
 * Author URI:        https://github.com/frontiers-wp/simplyhideauthor
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       simply-hide-author
 * Domain Path:       /languages
 * License:           GPLv2
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 *
 * You should have received a copy of the GNU General Public License
 * along with Simply Hide Author. If not, see <https://www.gnu.org/licenses/gpl-2.0.html/>.
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'SIMPLY_HIDE_AUTHOR_VERSION', '1.0.1' );

/**
 * Base URL of plugin
 */
if ( ! defined( 'SIMPLY_HIDE_AUTHOR_VERSION_BASEURL' ) ) {
	define( 'SIMPLY_HIDE_AUTHOR_VERSION_BASEURL', plugin_dir_url( __FILE__ ) );
}

/**
 * Base Name of plugin
 */
if ( ! defined( 'SIMPLY_HIDE_AUTHOR_VERSION_BASENAME' ) ) {
	define( 'SIMPLY_HIDE_AUTHOR_VERSION_BASENAME', plugin_basename( __FILE__ ) );
}

/**
 * Base PATH of plugin
 */
if ( ! defined( 'SIMPLY_HIDE_AUTHOR_VERSION_BASEPATH' ) ) {
	define( 'SIMPLY_HIDE_AUTHOR_VERSION_BASEPATH', plugin_dir_path( __FILE__ ) );
}

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-simply-hide-author-activator.php
 */
function activate_simply_hide_author() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-simply-hide-author-activator.php';
	Simply_Hide_Author_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-simply-hide-author-deactivator.php
 */
function deactivate_simply_hide_author() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-simply-hide-author-deactivator.php';
	Simply_Hide_Author_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_simply_hide_author' );
register_deactivation_hook( __FILE__, 'deactivate_simply_hide_author' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-simply-hide-author.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_simply_hide_author() {

	$plugin = new Simply_Hide_Author();
}
run_simply_hide_author();
