<?php
/**
 * Class to modify WordPress REST API user endpoints
 */
class WpV2UsersReturn
{
    /**
     * Constructor - hooks into WordPress initialization
     */
    public function __construct()
    {
        add_filter('rest_endpoints', [$this, 'removeUserEndpoints']);
    }

    /**
     * Remove default WordPress REST API user endpoints
     *
     * @param array $endpoints Registered REST API endpoints
     * @return array Filtered endpoints with user endpoints removed
     */
    public function removeUserEndpoints(array $endpoints): array
    {
        // Remove the users collection endpoint
        if (isset($endpoints['/wp/v2/users'])) {
            unset($endpoints['/wp/v2/users']);
        }

        // Remove the single user endpoint
        if (isset($endpoints['/wp/v2/users/(?P<id>[\d]+)'])) {
            unset($endpoints['/wp/v2/users/(?P<id>[\d]+)']);
        }

        return $endpoints;
    }
}

// Initialize the class
new WpV2UsersReturn();