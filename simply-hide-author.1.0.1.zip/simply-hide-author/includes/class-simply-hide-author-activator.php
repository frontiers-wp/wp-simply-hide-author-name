<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Simply_Hide_Author
 * @subpackage Simply_Hide_Author/includes
 * @author     Frontiers <wordpress@bekamhealing.com>
 */

if (!class_exists('Simply_Hide_Author_Activator')) {

    class Simply_Hide_Author_Activator {

        /**
         * Main activation handler.
         * Initializes plugin options and sets up uninstall hook.
         *
         * @since    1.0.0
         */
        public static function activate() {
            $activator = new self();
            $activator->install();

            // Register uninstall hook
            register_uninstall_hook(__FILE__, ['Simply_Hide_Author_Activator', 'uninstall']);
        }

        /**
         * Initializes plugin options during activation.
         *
         * @since    1.0.0
         */
        protected function install() {
            $this->init_options();
        }

        /**
         * Sets up default plugin options.
         *
         * @since    1.0.0
         */
        private function init_options() {
            // Add your default options initialization here
            // Example:
            // $default_options = [
            //     'hide_author' => 0,
            //     'version'     => '1.0.0'
            // ];
            // update_option('simply_hide_author_options', $default_options);
        }

        /**
         * Uninstall handler.
         * Cleans up plugin data when uninstalled.
         *
         * @since    1.0.0
         */
        public static function uninstall() {
            // Add your uninstall cleanup code here
            // Example:
            // delete_option('simply_hide_author_options');
        }
    }
}