<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
/**
 * Register all actions and filters for the plugin.
 *
 * Maintains a list of all hooks that are registered throughout the plugin
 * and registers them with the WordPress API.
 *
 * @package    Simply_Hide_Author
 * @subpackage Simply_Hide_Author/includes
 * @author     Frontiers <wordpress@bekamhealing.com>
 */
class Simply_Hide_Author_Loader {

    /**
     * Plugin configuration (e.g., prefix for options).
     *
     * @var array
     */
    protected $config = [
        'prefix'          => 'sha_',  // Example prefix
        'prefixSeparator' => '_',     // Separator for prefixed options
    ];

    /**
     * Helper for using prefixes for all references.
     *
     * @param string $name The option name to prefix.
     * @return string The prefixed option name.
     */
    public function setPrefix($name) {
        return ((strpos($name, $this->config['prefix']) === 0) ? '' : $this->config['prefix']) . $this->config['prefixSeparator'] . $name;
    }

    /**
     * Helper for getting prefixed options.
     *
     * @param string $name The option name to retrieve.
     * @return mixed The option value.
     */
    public function getPrefixedOption($name) {
        return get_option($this->setPrefix($name));
    }

	/**
	 * The array of actions registered with WordPress.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      array    $actions    The actions registered with WordPress to fire when the plugin loads.
	 */
	protected $actions;

	/**
	 * The array of filters registered with WordPress.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      array    $filters    The filters registered with WordPress to fire when the plugin loads.
	 */
	protected $filters;

    /**
	 * Initialize the collections used to maintain the actions and filters.
	 *
	 * @since    1.0.0
	 */
	public function __construct() {

		$this->actions = array();
		$this->filters = array();

	}

    /**
     * Add a new action to the collection.
     *
     * @param string $hook          The name of the WordPress action.
     * @param object $component     The instance of the object where the callback is defined.
     * @param string $callback      The name of the function to call.
     * @param int    $priority      Optional. The priority at which the function should fire. Default: 10.
     * @param int    $accepted_args Optional. The number of arguments to pass. Default: 1.
     */
    public function add_action($hook, $component, $callback, $priority = 10, $accepted_args = 1) {
        $this->actions = $this->add($this->actions, $hook, $component, $callback, $priority, $accepted_args);
    }

    /**
     * Add a new filter to the collection.
     *
     * @param string $hook          The name of the WordPress filter.
     * @param object $component     The instance of the object where the callback is defined.
     * @param string $callback      The name of the function to call.
     * @param int    $priority      Optional. The priority at which the function should fire. Default: 10.
     * @param int    $accepted_args Optional. The number of arguments to pass. Default: 1.
     */
    public function add_filter($hook, $component, $callback, $priority = 10, $accepted_args = 1) {
        $this->filters = $this->add($this->filters, $hook, $component, $callback, $priority, $accepted_args);
    }

    /**
     * Utility function to register actions/filters in a single collection.
     *
     * @param array  $hooks         The collection of hooks (actions/filters).
     * @param string $hook          The name of the WordPress hook.
     * @param object $component     The instance of the object where the callback is defined.
     * @param string $callback      The name of the function to call.
     * @param int    $priority      The priority at which the function should fire.
     * @param int    $accepted_args The number of arguments to pass.
     * @return array The updated collection of hooks.
     */
    private function add($hooks, $hook, $component, $callback, $priority, $accepted_args) {
        $hooks[] = [
            'hook'          => $hook,
            'component'     => $component,
            'callback'      => $callback,
            'priority'      => $priority,
            'accepted_args' => $accepted_args,
        ];
        return $hooks;
    }

    /**
     * Register the filters and actions with WordPress.
     */
    public function run() {
        foreach ($this->filters as $hook) {
            add_filter(
                $hook['hook'],
                [$hook['component'], $hook['callback']],
                $hook['priority'],
                $hook['accepted_args']
            );
        }

        foreach ($this->actions as $hook) {
            add_action(
                $hook['hook'],
                [$hook['component'], $hook['callback']],
                $hook['priority'],
                $hook['accepted_args']
            );
        }
    }
}